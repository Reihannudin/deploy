import {DeleteAlertComponent} from "../Components/Helper/DeleteAlert.Component";


function Test () {
    return(
        <>
            <DeleteAlertComponent />
        </>
    )
}
export default Test