
function Failed(){
    return(
        <>
        </>
    )
}

export default Failed