

export const StatusSuccessComponent = () => {
    return(
        <>

        </>
    )
}