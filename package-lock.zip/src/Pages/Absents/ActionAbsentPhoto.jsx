import {ActionAbsentPhotoComponent} from "../../Components/Absent/ActionAbsentPhoto.Component";

function ActionAbsentPhoto (){
    return(
        <>
            <div className="h-full " style={{ background:"#FFFFFF"}}>
                <ActionAbsentPhotoComponent />
            </div>
        </>
    )
}

export default ActionAbsentPhoto